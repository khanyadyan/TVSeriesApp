import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SeriesTest {

    @Test
    public void testSearchSeriesNotFound() {
        Series app = new Series();
        assertNull(app.searchSeries("999"));  // Nothing added yet
    }

    @Test
    public void testCaptureAndSearchSeries() {
        Series app = new Series();
        SeriesModel model = new SeriesModel("001", "Breaking Code", 16, 10);
        // Simulate adding directly to the list for testing instead of console input
        assertEquals("001", model.getSeriesId());
        assertEquals("Breaking Code", model.getSeriesName());
        assertEquals(16, model.getSeriesAge());
        assertEquals(10, model.getNumberOfEpisodes());
    }
}