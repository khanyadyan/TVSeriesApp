public class SeriesModel {
    private final String seriesId;
    private final String seriesName;
    private final int seriesAge;
    private final int numberOfEpisodes;

    // Constructor
    public SeriesModel(String seriesId, String seriesName, int seriesAge, int numberOfEpisodes) {
        this.seriesId = seriesId;
        this.seriesName = seriesName;
        this.seriesAge = seriesAge;
        this.numberOfEpisodes = numberOfEpisodes;
    }

    // Getters
    public String getSeriesId() { return seriesId; }
    public String getSeriesName() { return seriesName; }
    public int getSeriesAge() { return seriesAge; }
    public int getNumberOfEpisodes() { return numberOfEpisodes; }

    @Override
    public String toString() {
        return "Series ID: " + seriesId +
               ", Name: " + seriesName +
               ", Age Restriction: " + seriesAge +
               ", Episodes: " + numberOfEpisodes;
    }
}