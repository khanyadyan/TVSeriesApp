import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Series seriesApp = new Series();
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== TV SERIES MANAGEMENT MENU ===");
            System.out.println("1. Capture New Series");
            System.out.println("2. Search Series");
            System.out.println("3. Update Series");
            System.out.println("4. Delete Series");
            System.out.println("5. View Report");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice;
            try {
                choice = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Enter a number.");
                continue;
            }

            switch (choice) {
                case 1 -> seriesApp.captureSeries();
                case 2 -> seriesApp.searchSeries();
                case 3 -> seriesApp.updateSeries();
                case 4 -> seriesApp.deleteSeries();
                case 5 -> seriesApp.seriesReport();
                case 6 -> seriesApp.exitSeriesApplication();
                default -> System.out.println("❌ Invalid option! Try again.");
            }
        }
    }
}