import java.util.ArrayList;
import java.util.Scanner;

public class Series {
    private final ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private final Scanner input = new Scanner(System.in);

    // Capture new series
    public void captureSeries() {
        System.out.print("Enter Series ID: ");
        String id = input.nextLine();

        System.out.print("Enter Series Name: ");
        String name = input.nextLine();

        int age;
        while (true) {
            try {
                System.out.print("Enter Age Restriction (2–18): ");
                age = Integer.parseInt(input.nextLine());
                if (age >= 2 && age <= 18) break;
                else System.out.println("Invalid age! Enter between 2 and 18.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }

        System.out.print("Enter Number of Episodes: ");
        int episodes = Integer.parseInt(input.nextLine());

        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("✅ Series saved successfully!\n");
    }

    // Search
    public SeriesModel searchSeries(String id) {
        for (SeriesModel s : seriesList) {
            if (s.getSeriesId().equalsIgnoreCase(id)) {
                return s;
            }
        }
        return null;
    }

    public void searchSeries() {
        System.out.print("Enter Series ID to search: ");
        String id = input.nextLine();
        SeriesModel result = searchSeries(id);
        if (result != null) {
            System.out.println("Series Found: " + result);
        } else {
            System.out.println("❌ No series data found.");
        }
    }

    // Update
    public void updateSeries() {
        System.out.print("Enter Series ID to update: ");
        String id = input.nextLine();
        SeriesModel found = searchSeries(id);

        if (found == null) {
            System.out.println("❌ Series not found.");
            return;
        }

        System.out.print("Enter New Name: ");
        String name = input.nextLine();

        int age;
        while (true) {
            try {
                System.out.print("Enter New Age Restriction (2–18): ");
                age = Integer.parseInt(input.nextLine());
                if (age >= 2 && age <= 18) break;
                else System.out.println("Invalid age! Enter between 2 and 18.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter a number.");
            }
        }

        System.out.print("Enter New Number of Episodes: ");
        int episodes = Integer.parseInt(input.nextLine());

        seriesList.remove(found);
        seriesList.add(new SeriesModel(id, name, age, episodes));
        System.out.println("✅ Series updated successfully!");
    }

    // Delete
    public void deleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = input.nextLine();
        SeriesModel found = searchSeries(id);

        if (found == null) {
            System.out.println("❌ Series not found.");
            return;
        }

        System.out.print("Are you sure you want to delete this series? (y/n): ");
        String confirm = input.nextLine();
        if (confirm.equalsIgnoreCase("y")) {
            seriesList.remove(found);
            System.out.println("✅ Series deleted.");
        } else {
            System.out.println("❌ Deletion cancelled.");
        }
    }

    // Report
    public void seriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("📭 No series available.");
            return;
        }
        System.out.println("=== TV Series Report ===");
        for (SeriesModel s : seriesList) {
            System.out.println(s);
        }
    }

    // Exit
    public void exitSeriesApplication() {
        System.out.println("👋 Exiting application. Goodbye!");
        System.exit(0);
    }
}