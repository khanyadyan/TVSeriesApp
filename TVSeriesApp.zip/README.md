# TV Series Management App

A Java console application for managing TV series.
